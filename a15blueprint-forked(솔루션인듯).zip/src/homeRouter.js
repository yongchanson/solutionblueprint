import express, { Router } from "express";
import { home, readFile } from "./homeController";
import { acceptFiles } from "./middlewares";
const homeRouter = express.Router();

homeRouter.get("/", home);

export default homeRouter;
