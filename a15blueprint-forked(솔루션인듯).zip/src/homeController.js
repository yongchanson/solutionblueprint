import fs from "fs";
export const home = (req, res) => {
  fs.readdir("uploads", (err, files) => {
    if (err) throw err;
    return res.render("home", { pageTitle: "Upload File", files });
  });
};
export const getReadFile = (req, res) => {
  const { id } = req.params;
  fs.readFile(`uploads/${id}`, "utf-8", (err, data) => {
    if (err) throw err;
    return res.render("view", { pageTitle: id, id, data });
  });
};
export const readFile = (req, res) => {
  const { file } = req;
  if (file === undefined) {
    return res.status(404).render("home", {
      pageTitle: "Upload File",
      errorMsg: "Please Upload Your File."
    });
  }
  fs.readFile(file.path, "utf-8", (err, data) => {
    if (err) throw err;
    const id = file.originalname;
    return res.render("view", { pageTitle: id, id, data });
  });
};
