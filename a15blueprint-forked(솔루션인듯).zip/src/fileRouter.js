import express, { Router } from "express";
import { readFile, getReadFile } from "./homeController";
import { acceptFiles } from "./middlewares";
const fileRouter = express.Router();

fileRouter.route("/").post(acceptFiles.single("txt_file"), readFile);
fileRouter.get("/:id", getReadFile);
export default fileRouter;
