/*
You DONT have to import the Movie with your username.
Because it's a default export we can nickname it whatever we want.
So import Movie from "./models"; will work!
You can do Movie.find() or whatever you need like normal!
*/
import Movie from "./models/Movie";

// Add your magic here!

export const home = async (req, res) => {
  const movies = await Movie.find({});
  // console.log(movies);
  return res.render("home", { pageTitle: "Home", movies });
};

export const watch = async (req, res) => {
  const {
    params: { id }
  } = req;
  const movie = await Movie.findById(id);
  if (movie) {
    return res.render("watch", { pageTitle: movie.title, movie });
  }
  return res.render("404", { pageTitle: "404 found" });
};

export const search = async (req, res) => {
  const { keyword } = req.query;
  let movies = [];
  if (keyword) {
    movies = await Movie.find({
      // title: keyword
      title: {
        $regex: new RegExp(`${keyword}$`, "i")
      }
    });
    // return res.render("search", {
    //   pageTitle: `Searching : ${keyword}`,
    //   movies
    // });
  }
  return res.render("search", {
    pageTitle: `Searching : ${keyword}`,
    movies
  });
};

export const getEdit = async (req, res) => {
  const { id } = req.params;
  const movie = await Movie.findById(id);
  if (!movie) {
    return res.render("404", { pageTitle: "404 found." });
  }
  return res.render("edit", { pageTitle: `Edit: ${movie.title}`, movie });
};

export const postEdit = async (req, res) => {
  const { id } = req.params;
  const { title, summary, year, rating, genres } = req.body;

  // const movie = await Movie.exists({ _id: id });
  // console.log(id);
  const movie = await Movie.findById(id);
  if (!movie) {
    return res.render("404", { pageTitle: "404 found." });
  }

  movie.title = title;
  movie.summar = summary;
  movie.year = year;
  movie.rating = rating;
  movie.genres = genres
    .split(",")
    .map((word) => (word.startsWith("[") ? word : `${word}`));
  await movie.save();
  return res.redirect(`/`);
};

export const getUpload = (req, res) => {
  return res.render("upload", { pageTitle: "Upload Movie" });
};

export const postUpload = async (req, res) => {
  const { title, summary, year, rating, genres } = req.body;
  try {
    await Movie.create({
      title,
      summary,
      year,
      rating,
      genres: genres.split(",")
    });
    return res.redirect("/");
  } catch (error) {
    // console.log(error);
    return res.render("upload", {
      pageTitle: "Upload Movie Error"
    });
  }
};

export const deleteMovie = async (req, res) => {
  const { id } = req.params;
  await Movie.findByIdAndDelete(id);
  return res.redirect("/");
};
