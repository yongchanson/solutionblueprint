export const home = (req, res) => res.render("home", { pageTitle: "Home" });
export const trending = (req, res) => res.render("trending", { pageTitle: "Trending" });
export const newStories = (req, res) => res.render("newstories", { pageTitle: "NewStories" });
export const seeStory = (req, res) => res.render("seestory", { pageTitle: "SeeUser" , ID : `${req.params.id}`});
export const editStory = (req, res) => res.render("editstory", { pageTitle: "editStory" , ID : `${req.params.id}`});
export const deleteStory = (req, res) => res.render("deletestory", { pageTitle: "DeleteStory" , ID : `${req.params.id}`});
