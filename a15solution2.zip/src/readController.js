import fs from "fs";

export const home = (req, res) => {
  return res.render("home", { pageTitle: "Home" });
};

export const getRead = (req, res) => {
  res.render("read", { pageTitle: "TXT2HTML!" });
};

export const postRead = (req, res) => {
  const { path: filePath } = req.file;
  console.log(filePath);

  fs.readFile(filePath, "utf8", (err, data) => {
    if (err) throw err;
    // console.log(data);
    return res.render("home", { pageTitle: "Home", fileContent: data });
  });
};
