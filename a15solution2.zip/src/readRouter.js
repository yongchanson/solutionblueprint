import express from "express";
import multer from "multer";

import { home, getRead, postRead } from "./readController";

const readRouter = express.Router();

export const txtUpload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10000000
  }
});

readRouter.get("/", home);
readRouter.route("/read").get(getRead).post(txtUpload.single("txt"), postRead);

export default readRouter;
