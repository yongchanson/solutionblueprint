import { getMovieById, getMovies, addMovie } from "./db";

export const home = (req, res) =>
  res.render("movies", { movies: getMovies(), pageTitle: "Movies!" });

export const movieDetail = (req, res) => {
  const {
    params: { id }
  } = req;
  const movie = getMovieById(id);
  if (!movie) {
    res.render("404", { pageTitle: "Movie not found" });
  }
  return res.render("detail", { movie });
};

export const getadd = (req, res) =>
  res.render("add", { pageTitle: "Add Movies!" });

export const postadd = (req, res) => {
  
  const { body: { title, synopsis, genres } } = req;
  const newMovie = { title, synopsis, genres : genres.split(",").map((word) => `${word}`) };
  addMovie(newMovie);
  return res.redirect("/");
  
  // if(error){
  //   res.render("add", { pageTitle: "Add Movies!" });
  // }  
};
  
  // res.render("add", { pageTitle: "Add Movies!" });

/*
Write the controller or controllers you need to render the form
and to handle the submission
*/
