import express from "express";
import { home, movieDetail, getadd, postadd } from "./movieController";

const movieRouter = express.Router();

// create the '/' route
// create the /:id route
// create the /add route (GET + POST)
movieRouter.get("/", home);
// movieRouter.get("/add", add);
movieRouter.route("/add").get(getadd).post(postadd);
movieRouter.get("/:id", movieDetail);

export default movieRouter;
